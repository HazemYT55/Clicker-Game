
import { GoogleGenAI, Type } from "@google/genai";
import { OracleProphecy } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export async function getOracleProphecy(stardust: number, totalUpgrades: number): Promise<OracleProphecy> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `The player has ${stardust} stardust and ${totalUpgrades} cosmic upgrades. 
      Act as the Galactic Oracle. Give a cryptic but inspiring one-sentence prophecy about their cosmic expansion.
      Then, determine a random buff: 'click' or 'passive' (income), with a multiplier between 1.5 and 5.0, 
      lasting between 30 and 120 seconds.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING, description: "A mystical cosmic prophecy." },
            buffType: { type: Type.STRING, enum: ["click", "passive"] },
            multiplier: { type: Type.NUMBER },
            durationSeconds: { type: Type.NUMBER }
          },
          required: ["text", "buffType", "multiplier", "durationSeconds"]
        }
      }
    });

    const data = JSON.parse(response.text);
    return {
      text: data.text,
      buffType: data.buffType as 'click' | 'passive',
      multiplier: data.multiplier,
      durationMs: data.durationSeconds * 1000,
      timestamp: Date.now()
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    // Fallback prophecy
    return {
      text: "The stars align for your success, though the path is dimly lit.",
      buffType: 'passive',
      multiplier: 2.0,
      durationMs: 60000,
      timestamp: Date.now()
    };
  }
}

export async function getMilestoneMessage(stardust: number): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `The player just hit ${stardust} stardust in a cosmic clicker game. 
      Generate a short, flavorful one-sentence galactic news headline about this event.`,
    });
    return response.text.trim();
  } catch {
    return `Galactic sectors report a massive surge in stardust activity!`;
  }
}
