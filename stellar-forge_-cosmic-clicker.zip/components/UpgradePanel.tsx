
import React from 'react';
import { Upgrade } from '../types';
import { INITIAL_UPGRADES } from '../constants';
import { Star, Zap, MousePointer2, TrendingUp } from 'lucide-react';

interface UpgradePanelProps {
  stardust: number;
  ownedUpgrades: Record<string, number>;
  onBuy: (upgrade: Upgrade) => void;
  income: number;
  clickValue: number;
}

const UpgradePanel: React.FC<UpgradePanelProps> = ({ stardust, ownedUpgrades, onBuy, income, clickValue }) => {
  return (
    <div className="w-full lg:w-96 bg-slate-900/80 backdrop-blur-xl border-l border-white/10 flex flex-col h-full overflow-hidden">
      <div className="p-6 border-b border-white/10">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <TrendingUp className="text-blue-400" size={24} />
          Galactic Forge
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/5 p-3 rounded-xl">
            <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Per Second</div>
            <div className="text-lg font-bold text-green-400">{income.toFixed(1)}</div>
          </div>
          <div className="bg-white/5 p-3 rounded-xl">
            <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Per Click</div>
            <div className="text-lg font-bold text-blue-400">{clickValue.toFixed(1)}</div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
        {INITIAL_UPGRADES.map(upgrade => {
          const count = ownedUpgrades[upgrade.id] || 0;
          const cost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, count));
          const canAfford = stardust >= cost;

          return (
            <button
              key={upgrade.id}
              onClick={() => onBuy(upgrade)}
              disabled={!canAfford}
              className={`w-full p-4 rounded-xl border transition-all text-left flex items-start gap-4 ${
                canAfford 
                  ? 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-blue-500/50 cursor-pointer' 
                  : 'bg-black/20 border-white/5 opacity-60 cursor-not-allowed'
              }`}
            >
              <div className={`p-2 rounded-lg ${upgrade.type === 'click' ? 'bg-blue-500/20 text-blue-400' : 'bg-purple-500/20 text-purple-400'}`}>
                {upgrade.type === 'click' ? <MousePointer2 size={20} /> : <Zap size={20} />}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-white">{upgrade.name}</span>
                  <span className="text-sm font-medium text-blue-400">Lv.{count}</span>
                </div>
                <p className="text-xs text-slate-400 mb-2 leading-tight">
                  {upgrade.description}
                </p>
                <div className="flex items-center gap-1 text-sm font-bold text-yellow-500">
                  <Star size={14} />
                  {cost.toLocaleString()}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
};

export default UpgradePanel;
