
import React, { useState } from 'react';
import { OracleProphecy, LogEntry } from '../types';
import { getOracleProphecy } from '../services/geminiService';
import { Sparkles, MessageSquare, Timer, ArrowUpCircle } from 'lucide-react';
import { ORACLE_COST } from '../constants';

interface OraclePanelProps {
  stardust: number;
  totalUpgrades: number;
  onProphecy: (prophecy: OracleProphecy) => void;
  activeProphecy: OracleProphecy | null;
  logs: LogEntry[];
}

const OraclePanel: React.FC<OraclePanelProps> = ({ stardust, totalUpgrades, onProphecy, activeProphecy, logs }) => {
  const [loading, setLoading] = useState(false);
  const canAfford = stardust >= ORACLE_COST;

  const handleConsult = async () => {
    if (!canAfford || loading) return;
    setLoading(true);
    const prophecy = await getOracleProphecy(stardust, totalUpgrades);
    onProphecy(prophecy);
    setLoading(false);
  };

  const getTimeLeft = () => {
    if (!activeProphecy) return 0;
    const elapsed = Date.now() - activeProphecy.timestamp;
    return Math.max(0, Math.ceil((activeProphecy.durationMs - elapsed) / 1000));
  };

  const [timeLeft, setTimeLeft] = useState(getTimeLeft());

  React.useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(getTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
  }, [activeProphecy]);

  return (
    <div className="p-4 bg-slate-900/60 backdrop-blur-md rounded-2xl border border-indigo-500/30 shadow-lg shadow-indigo-500/10">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-indigo-300 flex items-center gap-2">
          <Sparkles size={20} />
          Space Oracle
        </h3>
        <button
          onClick={handleConsult}
          disabled={!canAfford || loading}
          className={`px-4 py-2 rounded-xl font-bold transition-all ${
            canAfford && !loading
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:scale-105 active:scale-95 shadow-lg shadow-indigo-600/30'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-50'
          }`}
        >
          {loading ? 'Consulting...' : `Consult (${ORACLE_COST})`}
        </button>
      </div>

      {activeProphecy && timeLeft > 0 ? (
        <div className="bg-indigo-900/30 border border-indigo-500/50 p-4 rounded-xl mb-4 animate-pulse-slow">
          <p className="italic text-indigo-100 mb-2 leading-relaxed">
            "{activeProphecy.text}"
          </p>
          <div className="flex items-center gap-4 text-sm font-semibold">
            <div className="flex items-center gap-1 text-indigo-300">
              <ArrowUpCircle size={16} />
              {activeProphecy.multiplier}x {activeProphecy.buffType}
            </div>
            <div className="flex items-center gap-1 text-slate-400">
              <Timer size={16} />
              {timeLeft}s
            </div>
          </div>
        </div>
      ) : (
        <div className="text-slate-500 text-sm italic mb-4 p-4 border border-dashed border-slate-700 rounded-xl">
          The stars are quiet. Seek guidance to reveal your destiny.
        </div>
      )}

      <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar">
        <div className="text-[10px] uppercase tracking-widest text-slate-600 font-bold mb-2">Universe Logs</div>
        {logs.slice().reverse().map(log => (
          <div key={log.id} className="text-xs flex gap-2">
            <span className="text-slate-500">[{new Date(log.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}]</span>
            <span className={
              log.type === 'milestone' ? 'text-yellow-400' : 
              log.type === 'oracle' ? 'text-indigo-400' : 'text-slate-300'
            }>
              {log.message}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OraclePanel;
