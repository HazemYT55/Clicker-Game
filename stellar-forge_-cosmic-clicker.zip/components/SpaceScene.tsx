
import React, { useState } from 'react';

interface SpaceSceneProps {
  onTap: (x: number, y: number) => void;
  stardust: number;
}

const SpaceScene: React.FC<SpaceSceneProps> = ({ onTap, stardust }) => {
  const [clicks, setClicks] = useState<{ id: number; x: number; y: number; text: string }[]>([]);

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const x = e.clientX;
    const y = e.clientY;
    onTap(x, y);

    const id = Date.now();
    const newClick = { id, x, y, text: `+${stardust.toFixed(1)}` };
    setClicks(prev => [...prev, newClick]);
    
    setTimeout(() => {
      setClicks(prev => prev.filter(c => c.id !== id));
    }, 1000);
  };

  return (
    <div 
      className="relative flex-1 h-full cursor-pointer overflow-hidden select-none"
      onClick={handleClick}
    >
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-64 h-64 md:w-96 md:h-96 group">
          {/* Glowing Aura */}
          <div className="absolute inset-0 bg-blue-500 rounded-full blur-[60px] opacity-20 group-hover:opacity-40 transition-opacity"></div>
          
          {/* Core Star */}
          <div className="absolute inset-4 bg-gradient-to-br from-indigo-300 via-blue-500 to-purple-800 rounded-full shadow-[0_0_100px_rgba(59,130,246,0.6)] animate-float transform active:scale-95 transition-transform">
            <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.4),transparent)]"></div>
          </div>
        </div>
      </div>

      {/* Floating particles/points */}
      {clicks.map(click => (
        <div 
          key={click.id}
          className="absolute pointer-events-none text-2xl font-bold text-blue-300 animate-bounce opacity-0 transition-opacity"
          style={{ 
            left: click.x - 20, 
            top: click.y - 20,
            animation: 'float-up 1s forwards ease-out'
          }}
        >
          {click.text}
        </div>
      ))}

      <style>{`
        @keyframes float-up {
          0% { transform: translateY(0); opacity: 1; }
          100% { transform: translateY(-100px); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default SpaceScene;
