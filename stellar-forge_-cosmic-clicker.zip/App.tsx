
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { GameState, Upgrade, OracleProphecy, LogEntry } from './types';
import { INITIAL_UPGRADES, ORACLE_COST } from './constants';
import { getMilestoneMessage } from './services/geminiService';
import SpaceScene from './components/SpaceScene';
import UpgradePanel from './components/UpgradePanel';
import OraclePanel from './components/OraclePanel';
import { Layers, Rocket, Star } from 'lucide-react';

const App: React.FC = () => {
  const [stardust, setStardust] = useState(0);
  const [totalStardust, setTotalStardust] = useState(0);
  const [ownedUpgrades, setOwnedUpgrades] = useState<Record<string, number>>({});
  const [activeProphecy, setActiveProphecy] = useState<OracleProphecy | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [milestones, setMilestones] = useState<number[]>([100, 1000, 10000, 100000]);

  // Derived Values
  const getUpgradeValue = (type: 'click' | 'passive') => {
    return INITIAL_UPGRADES
      .filter(u => u.type === type)
      .reduce((acc, u) => {
        const count = ownedUpgrades[u.id] || 0;
        return acc + (u.value * count);
      }, type === 'click' ? 1 : 0);
  };

  const incomeBase = getUpgradeValue('passive');
  const clickBase = getUpgradeValue('click');

  const income = useMemo(() => {
    let multiplier = 1;
    if (activeProphecy && activeProphecy.buffType === 'passive') {
      const elapsed = Date.now() - activeProphecy.timestamp;
      if (elapsed < activeProphecy.durationMs) {
        multiplier = activeProphecy.multiplier;
      }
    }
    return incomeBase * multiplier;
  }, [incomeBase, activeProphecy]);

  const clickValue = useMemo(() => {
    let multiplier = 1;
    if (activeProphecy && activeProphecy.buffType === 'click') {
      const elapsed = Date.now() - activeProphecy.timestamp;
      if (elapsed < activeProphecy.durationMs) {
        multiplier = activeProphecy.multiplier;
      }
    }
    return clickBase * multiplier;
  }, [clickBase, activeProphecy]);

  // Effects
  useEffect(() => {
    const tick = setInterval(() => {
      setStardust(prev => prev + (income / 10));
      setTotalStardust(prev => prev + (income / 10));
    }, 100);
    return () => clearInterval(tick);
  }, [income]);

  // Milestone Checker
  useEffect(() => {
    if (milestones.length > 0 && totalStardust >= milestones[0]) {
      const currentMilestone = milestones[0];
      setMilestones(prev => prev.slice(1));
      
      const fetchMilestone = async () => {
        const msg = await getMilestoneMessage(currentMilestone);
        addLog(msg, 'milestone');
      };
      fetchMilestone();
    }
  }, [totalStardust, milestones]);

  const addLog = (message: string, type: LogEntry['type'] = 'info') => {
    const newLog: LogEntry = {
      id: Math.random().toString(36).substr(2, 9),
      message,
      time: Date.now(),
      type
    };
    setLogs(prev => [...prev, newLog].slice(-20));
  };

  const handleTap = useCallback((x: number, y: number) => {
    setStardust(prev => prev + clickValue);
    setTotalStardust(prev => prev + clickValue);
  }, [clickValue]);

  const handleBuy = (upgrade: Upgrade) => {
    const count = ownedUpgrades[upgrade.id] || 0;
    const cost = Math.floor(upgrade.baseCost * Math.pow(upgrade.costMultiplier, count));
    
    if (stardust >= cost) {
      setStardust(prev => prev - cost);
      setOwnedUpgrades(prev => ({
        ...prev,
        [upgrade.id]: count + 1
      }));
      addLog(`Constructed level ${count + 1} ${upgrade.name}.`);
    }
  };

  const handleProphecy = (prophecy: OracleProphecy) => {
    setStardust(prev => prev - ORACLE_COST);
    setActiveProphecy(prophecy);
    addLog(`Prophecy received: "${prophecy.text.substring(0, 30)}..."`, 'oracle');
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen w-full relative">
      <div className="star-field"></div>
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative">
        {/* Header/Stats */}
        <div className="absolute top-0 left-0 right-0 p-8 flex justify-between items-start pointer-events-none z-10">
          <div className="pointer-events-auto">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/50">
                <Rocket className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white leading-none">Stellar Forge</h1>
                <span className="text-xs text-blue-400 font-bold tracking-widest uppercase">System Active</span>
              </div>
            </div>
            
            <div className="mt-6">
              <div className="flex items-center gap-2 mb-1">
                <Star className="text-yellow-500 fill-yellow-500" size={24} />
                <span className="text-4xl font-black text-white tracking-tight">
                  {Math.floor(stardust).toLocaleString()}
                </span>
              </div>
              <p className="text-slate-400 font-medium ml-8">Harvested Stardust</p>
            </div>
          </div>

          <div className="bg-slate-900/40 backdrop-blur-md border border-white/10 p-4 rounded-2xl pointer-events-auto hidden md:block">
            <div className="flex items-center gap-4 text-sm font-medium">
              <div className="text-slate-400">Total Lifetime: <span className="text-white">{Math.floor(totalStardust).toLocaleString()}</span></div>
              <div className="w-px h-4 bg-white/10"></div>
              <div className="text-slate-400">Upgrades: <span className="text-white">{Object.values(ownedUpgrades).reduce((a, b) => a + b, 0)}</span></div>
            </div>
          </div>
        </div>

        {/* Clicking Zone */}
        <SpaceScene onTap={handleTap} stardust={clickValue} />

        {/* Footer Overlay (Oracle + Logs) */}
        <div className="absolute bottom-8 left-8 w-80 md:w-96 hidden md:block">
          <OraclePanel 
            stardust={stardust} 
            totalUpgrades={Object.values(ownedUpgrades).reduce((a, b) => a + b, 0)}
            onProphecy={handleProphecy}
            activeProphecy={activeProphecy}
            logs={logs}
          />
        </div>
      </main>

      {/* Upgrade Side Panel */}
      <UpgradePanel 
        stardust={stardust}
        ownedUpgrades={ownedUpgrades}
        onBuy={handleBuy}
        income={income}
        clickValue={clickValue}
      />

      {/* Mobile Stats Floating Overlay */}
      <div className="lg:hidden fixed bottom-4 left-4 right-4 z-50">
         <div className="bg-slate-900/90 backdrop-blur-xl border border-white/10 p-4 rounded-2xl shadow-2xl flex justify-between items-center">
            <div className="flex flex-col">
               <span className="text-xs text-slate-400 uppercase font-bold tracking-tighter">Current Balance</span>
               <span className="text-xl font-bold text-yellow-500 flex items-center gap-1">
                  <Star size={16} className="fill-yellow-500"/>
                  {Math.floor(stardust).toLocaleString()}
               </span>
            </div>
            <div className="flex gap-4">
              <div className="text-right">
                <div className="text-[10px] text-slate-500 font-bold uppercase">Income</div>
                <div className="text-sm font-bold text-green-400">+{income.toFixed(1)}/s</div>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-slate-500 font-bold uppercase">Tap</div>
                <div className="text-sm font-bold text-blue-400">+{clickValue.toFixed(1)}</div>
              </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default App;
