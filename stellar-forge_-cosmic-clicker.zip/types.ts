
export interface Upgrade {
  id: string;
  name: string;
  description: string;
  baseCost: number;
  costMultiplier: number;
  type: 'click' | 'passive';
  value: number; // Value added per click or per second
}

export interface GameState {
  stardust: number;
  totalStardust: number;
  clicks: number;
  ownedUpgrades: Record<string, number>;
  lastSaved: number;
}

export interface OracleProphecy {
  text: string;
  buffType: 'click' | 'passive';
  multiplier: number;
  durationMs: number;
  timestamp: number;
}

export interface LogEntry {
  id: string;
  message: string;
  time: number;
  type: 'info' | 'milestone' | 'oracle';
}
