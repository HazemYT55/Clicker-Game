
import { Upgrade } from './types';

export const INITIAL_UPGRADES: Upgrade[] = [
  {
    id: 'nano_drone',
    name: 'Nano-Drone',
    description: 'Small robots that harvest particles.',
    baseCost: 15,
    costMultiplier: 1.15,
    type: 'passive',
    value: 0.1,
  },
  {
    id: 'plasma_drill',
    name: 'Plasma Drill',
    description: 'Extracts stardust from dormant nebula.',
    baseCost: 100,
    costMultiplier: 1.15,
    type: 'passive',
    value: 1,
  },
  {
    id: 'heavy_gloves',
    name: 'Heavy Gloves',
    description: 'Increases stardust collected per click.',
    baseCost: 50,
    costMultiplier: 1.25,
    type: 'click',
    value: 1,
  },
  {
    id: 'stellar_harvester',
    name: 'Stellar Harvester',
    description: 'Massive sails capturing solar winds.',
    baseCost: 1100,
    costMultiplier: 1.15,
    type: 'passive',
    value: 8,
  },
  {
    id: 'warp_capacitor',
    name: 'Warp Capacitor',
    description: 'Significantly boosts click efficiency.',
    baseCost: 2500,
    costMultiplier: 1.3,
    type: 'click',
    value: 10,
  },
  {
    id: 'neutron_forge',
    name: 'Neutron Forge',
    description: 'Harnesses the energy of a dead star.',
    baseCost: 12000,
    costMultiplier: 1.15,
    type: 'passive',
    value: 47,
  },
  {
    id: 'galactic_nexus',
    name: 'Galactic Nexus',
    description: 'A hub for all interdimensional resources.',
    baseCost: 150000,
    costMultiplier: 1.2,
    type: 'passive',
    value: 260,
  }
];

export const ORACLE_COST = 500;
